git clone https://submission.cg.tuwien.ac.at/gcg-2023/data.git
cp -r ./data/* ../
rm -r data/*