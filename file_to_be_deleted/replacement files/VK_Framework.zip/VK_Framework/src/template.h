#pragma once

#define PARSER(x) x

#ifndef STEP
#define STEP 6
#endif

#ifndef USE_BONUS
#define USE_BONUS 0
#endif

// #define USE_INTERN_SHADERS
